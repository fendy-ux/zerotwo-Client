package me.сс.zerotwo.api.event.events;

import me.сс.zerotwo.api.event.EventStage;

public
class UpdateWalkingPlayerEvent extends EventStage {

    public
    UpdateWalkingPlayerEvent ( int stage ) {
        super ( stage );
    }
}
