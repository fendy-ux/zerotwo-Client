package me.сс.zerotwo.mixin.mixins;

import net.minecraft.client.renderer.chunk.VisGraph;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(VisGraph.class)
public
class MixinVisGraph {


}
