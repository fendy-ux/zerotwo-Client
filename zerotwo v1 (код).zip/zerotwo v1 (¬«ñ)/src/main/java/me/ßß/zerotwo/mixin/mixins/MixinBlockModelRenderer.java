package me.сс.zerotwo.mixin.mixins;

import net.minecraft.client.renderer.BlockModelRenderer;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(BlockModelRenderer.class)
public
class MixinBlockModelRenderer {

}
