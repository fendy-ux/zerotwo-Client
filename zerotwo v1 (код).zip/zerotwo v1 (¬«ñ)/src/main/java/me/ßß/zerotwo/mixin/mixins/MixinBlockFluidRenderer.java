package me.сс.zerotwo.mixin.mixins;

import net.minecraft.client.renderer.BlockFluidRenderer;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(BlockFluidRenderer.class)
public
class MixinBlockFluidRenderer {

}