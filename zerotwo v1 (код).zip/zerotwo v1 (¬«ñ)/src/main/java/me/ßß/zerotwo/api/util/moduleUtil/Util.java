package me.сс.zerotwo.api.util.moduleUtil;

import net.minecraft.client.Minecraft;

public
interface Util {

    Minecraft mc = Minecraft.getMinecraft ( );

}
