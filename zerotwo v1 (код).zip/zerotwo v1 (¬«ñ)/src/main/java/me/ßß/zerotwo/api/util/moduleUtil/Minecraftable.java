package me.сс.zerotwo.api.util.moduleUtil;

import net.minecraft.client.Minecraft;

public
interface Minecraftable {
    Minecraft mc = Minecraft.getMinecraft ( );
}
